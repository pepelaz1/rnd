﻿Imports MersenneTwister

Public Class Randomizer
    Shared Sub RandomizeDeck(ByRef tmpCardDeck As String())
        Dim x, swap As String
        Dim r As Random
        Try
            r = New Random()
            For i As Integer = 0 To tmpCardDeck.GetUpperBound(0)
                x = r.Next(0, tmpCardDeck.GetUpperBound(0) + 1)
                swap = tmpCardDeck(x)
                tmpCardDeck(x) = tmpCardDeck(i)
                tmpCardDeck(i) = swap
            Next i

        Catch ex As Exception
            'HandleAllExceptions(ex)
        Finally
            r = Nothing
        End Try
    End Sub

    Shared Sub RandomizeDeckMT(ByRef tmpCardDeck As String())
        Dim x, swap As String
        Dim r As MTRandom
        Try
            r = New MTRandom()
            For i As Integer = 0 To tmpCardDeck.GetUpperBound(0)
                x = r.genrand_intRange(0, tmpCardDeck.GetUpperBound(0))
                swap = tmpCardDeck(x)
                tmpCardDeck(x) = tmpCardDeck(i)
                tmpCardDeck(i) = swap
            Next i

        Catch ex As Exception
            'HandleAllExceptions(ex)
        Finally
            r = Nothing
        End Try
    End Sub
End Class
